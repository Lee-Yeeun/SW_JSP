package com.jsp.util;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@WebListener
public class ApplicationConfig implements ServletContextListener{
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {

		HikariConfig hikariConfig = new HikariConfig();
		
		hikariConfig.setDriverClassName("org.mariadb.jdbc.Driver");
		hikariConfig.setJdbcUrl("jdbc:mariadb://10.10.14.30:3306/webdev");
		hikariConfig.setUsername("shopManager");
		hikariConfig.setPassword("1234");
		hikariConfig.setConnectionTestQuery("select now() from dual");
		hikariConfig.setMaximumPoolSize(10);
		hikariConfig.setPoolName("Mariadb-HikariCP");
		
		HikariDataSource ds = new HikariDataSource(hikariConfig);
		sce.getServletContext().setAttribute("dataSource", ds);
		
	}
}
